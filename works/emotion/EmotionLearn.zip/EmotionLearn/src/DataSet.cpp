#include "Util.h"
#include "DataSet.h"

#include <algorithm>
#include <sstream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <complex>
#include <utility>
#include <fstream>
#include <iostream>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cmath>

using std::string;
using std::vector;
using std::map;

string      ReplaceAll(const char* str)
{
    string result;
    bool flag = true;

    for (unsigned int i = 0; i < strlen(str); i ++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
        {
            result += 'a' + (str[i] - 'A');
            flag = false;
        } 
        else 
        { 
            if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= '0' && str[i] <= '9'))
            {
                result += str[i];
                flag = false;
            } 
            else 
            {
                if (! flag)
                    result += " ";
                flag = true;
            }
        }
    }
    return result;
}

// Corpus
Corpus::Corpus()
{
    terms.clear();
    users.clear();
    docs.clear();
    figs.clear();
}

Figure::Figure()
{
    features.clear();
}

void        Corpus::Clear()
{
    wordNum = 0;
    docNum = 0;
    terms.clear();
    users.clear();
    docs.clear();
    figs.clear();
}

// DataSet
DataSet::DataSet()
{
    corpus = new Corpus();
    userMap.clear();
    termMap.clear();
}

bool            DataSet::IsStopword(string word)
{
    if (stopwords.count(word) > 0 || word.length() < 2)
        return true;
    bool flag = true;
    for (unsigned int i = 0; i < word.length(); i ++)
        if (word[i] >= 'a' && word[i] <= 'z')
        {
            flag = false;
            break;
        }
    return flag;
}

int				DataSet::GetOrInsertUserId(const string& key)
{
    map<string, int>::iterator it = userMap.find(key);
    if (it != userMap.end())
        return it -> second;
    int id = (int) corpus -> users.size();
    corpus -> users.push_back(key);
    userMap.insert(make_pair(key, id));
	return id;
}

int				DataSet::GetOrInsertTermId(const string& key)
{
    map<string, int>::iterator it = termMap.find(key);
    if (it != termMap.end())
        return it -> second;
    int id = (int) corpus -> terms.size();
    corpus -> terms.push_back(key);
    termMap.insert(make_pair(key, id));
	return id;
}

int         DataSet::ReadStopword(const char* fileDir)
{
    stopwords.clear();
    vector<string> inputs = Util::ReadFromFile(fileDir);
    for (unsigned int i = 0; i < inputs.size(); i ++)
    {
        string word = Util::StringTokenize(inputs[i])[0];
        if (IsStopword(word))
            continue;
        stopwords.insert(word);
    }
    return 0;
}

int         DataSet::ReadCorpus(const char* fileDir)
{
    vector<string> inputs = Util::ReadFromFile(fileDir);
    unsigned int i = 0;
    while (i < inputs.size())
    {
        Figure* fig = new Figure();
        fig -> id = corpus -> figs.size();
        vector<string> tokens = Util::StringTokenize(inputs[i]);
        fig -> label = Util::String2Int(tokens[1]);
        fig -> name = tokens[0];
        for (unsigned int j = 2; j < tokens.size(); j ++)
        {
            double val = Util::String2Double(tokens[j]);
            fig -> features.push_back(val);
        }
        // read comments
        i ++;
        int M = Util::String2Int(inputs[i]);
        for (int m = 0; m < M; m ++)
        {
            Document* doc = new Document();
            doc -> id = corpus -> docs.size();
            doc -> figId = fig -> id;
            i ++;
            string user = inputs[i];
            int uid = GetOrInsertUserId(user);
            doc -> authorId = uid;
            i += 2;
            string content = ReplaceAll(inputs[i].c_str());
            tokens = Util::StringTokenize(content);
            for (unsigned int j = 0; j < tokens.size(); j ++)
            {
                string word = tokens[j];
                if (IsStopword(word))
                    continue;
                int tid = GetOrInsertTermId(tokens[j]);
                doc -> words.push_back(tid);
            }
            if (doc -> words.size() == 0)
                continue;
            corpus -> docs.push_back(doc);
        }
        i ++;
        corpus -> figs.push_back(fig);
    }

    corpus -> docNum = (int) corpus -> docs.size();
    corpus -> figNum = (int) corpus -> figs.size();
    corpus -> wordNum = (int) termMap.size();
    corpus -> figFeatureNum = (int) corpus -> figs[0] -> features.size();
    corpus -> authorNum = (int) userMap.size();
    printf("#documents: %d\n", corpus -> docNum);
    printf("#figures: %d\n", corpus -> figNum);
    printf("#terms: %d\n", corpus -> wordNum);
    printf("#authors: %d\n", corpus -> authorNum);
    printf("#features: %d\n", corpus -> figFeatureNum);
    return 0;
}
