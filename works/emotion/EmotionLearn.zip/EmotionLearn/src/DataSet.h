#pragma once

#include "Util.h"

#include <string>
#include <vector>
#include <map>

using std::string;
using std::vector;
using std::map;

class Document 
{
public:
    int                 id;
    int                 authorId;
    int                 figId;
    vector<int>         words;
};

class Figure
{
public:
    int                 id;
    int                 label;
    string              name;
    vector<double>      features;   
    Figure();
};

class Corpus
{
public:
    int                 authorNum;
    int                 docNum;
    int                 wordNum;
    int                 figNum;
    int                 figFeatureNum;
    vector<string>      terms;
    vector<string>      users;
    vector<Figure*>     figs;
    vector<Document*>   docs; // docs[i]: doc with id = i
    
    void                Clear();
    Corpus();
};

class DataSet
{
public:
    set<string>         stopwords;
    map<string, int>    termMap;
    map<string, int>    userMap;
    Corpus*             corpus;
    int                 ReadCorpus(const char* fileDir);
    int                 GetOrInsertUserId(const string& key);
    int                 GetOrInsertTermId(const string& key);
    int                 ReadStopword(const char* fileDir);
    bool                IsStopword(string word);
    DataSet();
};
