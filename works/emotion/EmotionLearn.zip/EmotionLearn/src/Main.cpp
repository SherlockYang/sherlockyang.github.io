#include "Model.h"
#include "DataSet.h"

#include <string>

using std::string;

void    ShowUsage()
{
    printf("Latent Emotion Learning Method v0.1                                 \n");
    printf("     by Yang Yang, Tsinghua University                              \n");
    printf("                                                                    \n");
    printf("Usage: emotion -data [options]                                      \n");
    printf("options include -stopword -topic -b0 -b1 -iter                      \n");
    printf("\n");
    //printf("##############################################################  \n");
    printf("   -data       string       : input data file direction             \n");
    printf("   -stopword    string      : stopwrod file direction               \n");
    printf("   -topic       int         : topic number, 25 as default           \n");
    printf("   -b0          double      : parameter of Beta, 10.0 as default    \n");
    printf("   -b1          double      : parameter of Beta, 5.0 as default     \n");
    printf("   -iter        int         : number of iterations, 100 as default  \n");
    //printf("##############################################################  \n");
    printf("\n");
}

int         main(int argc, char* argv[])
{
    string INPUT_FILE = "";
    string STOPWORD_FILE = "";
    string TOPIC_FILE = "output/topics.txt";
    string PZF_FILE = "output/pzf.txt";
    string GAUSSIAN_FILE = "output/gaussian.txt";
    string PZD_FILE = "output/pzd.txt";
    string PCD_FILE = "output/pcd.txt";
    //string INSTANCE_FILE = "output/emotion_instance.txt";
    int TOPIC_NUM = 25;
    double ALPHA = (TOPIC_NUM + 0.0) / 50;
    double BETA0 = 10.0;
    double BETA1 = 5.0;
    double GAMMA = (TOPIC_NUM + 0.0) / 50;
    double TAU = 0.01;
    int MAX_ITER = 100;
    int BURN_IN = (int) (MAX_ITER / 5);
    int SAMPLE_LAG = (int) 10;

    for (int i = 1; i < argc; i ++)
    {
        if (strcmp(argv[i], "-data") == 0)
        {
            INPUT_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-stopword") == 0)
        {
            STOPWORD_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-topic") == 0)
        {
            TOPIC_NUM = Util::String2Int(argv[++i]);
        }
        if (strcmp(argv[i], "-b0") == 0)
        {
            BETA0 = Util::String2Double(argv[++i]);
        }
        if (strcmp(argv[i], "-b1") == 0)
        {
            BETA1 = Util::String2Double(argv[++i]);
        }
        if (strcmp(argv[i], "-iter") == 0)
        {
            MAX_ITER = Util::String2Int(argv[++i]);
        }
        i ++;
    }
    //printf("%s\n", INPUT_FILE.c_str());

    if (INPUT_FILE == "")
    {
        ShowUsage();
        return 0;
    }


    DataSet* dataSet = new DataSet();
    if (STOPWORD_FILE != "")
        dataSet -> ReadStopword(STOPWORD_FILE.c_str());
    dataSet -> ReadCorpus(INPUT_FILE.c_str());
    Model* model = new Model(dataSet -> corpus);
    model -> K = TOPIC_NUM;
    model -> alpha = ALPHA;
    model -> beta[0] = BETA0 + 0.0;
    model -> beta[1] = BETA1 + 0.0;
    model -> gamma = GAMMA;
    model -> tau = TAU;
    model -> Train(MAX_ITER, BURN_IN, SAMPLE_LAG);
    model -> SaveTopic(TOPIC_FILE.c_str(), 50);
    model -> SavePzf(PZF_FILE.c_str());
    model -> SaveGaussian(GAUSSIAN_FILE.c_str());
    model -> SavePcd(PCD_FILE.c_str());
    model -> SavePzd(PZD_FILE.c_str());
    //model -> GenerateInstance(INSTANCE_FILE.c_str());
}
