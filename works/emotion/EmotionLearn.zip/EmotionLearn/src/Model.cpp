#include "Model.h"

#include <algorithm>
#include <sstream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <complex>
#include <utility>
#include <fstream>
#include <iostream>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cmath>

using namespace std;

Model::Model(Corpus* corpus)
{
    this -> corpus = corpus;
    D = corpus -> docNum;
    M = corpus -> figNum;
    W = corpus -> wordNum;
    A = corpus -> authorNum;
    T = corpus -> figFeatureNum;
    beta = new double[2];
}

double          Gaussian(double x, double u, double d)
{
    d += 1e-1;
    static const float inv_sqrt_2pi = 0.3989422804014327;
    double a = (x - u) / d;
    double res = inv_sqrt_2pi / d * exp(-0.5f * a * a);
    return res / 1e10;
}

int         Model::SampleEmotion(double x, int t, int f)
{
    double Kalpha = K * alpha;
    // do multinomial sampling via cumulative method
    double* p = new double[K];
    for (int k = 0; k < K; k++) 
    {
        p[k] = (nfz[f][k] + alpha) / (nf_z[f] + Kalpha) * Gaussian(x, mu[k][t], delta[k][t]);
        /*
        if (f == 3)
            printf("%d : %d %.5lf %.5lf %.5lf\n", k, nfz[f][k], p[k] * 1e10, Gaussian(x, mu[k][t], delta[k][t]) * 1e10, delta[k][t]);
        */
    }

    // cumulate multinomial parameters
    for (int k = 1; k < K; k++) 
	    p[k] += p[k - 1];
    // scaled sample because of unnormalized p[]
    double u = ((double) random() / RAND_MAX) * p[K - 1];

    int topic = 0;
    for (topic = 0; topic < K - 1; topic++)
	    if (p[topic] > u)
	        break;
    //printf("%.3lf %.3lf %d\n", p[K - 1], u, topic);
    delete[] p;
    return topic;
}

pair<int, int>      Model::SampleTopic(int d, int a, int w, int f)
{
    double KAlpha = K * alpha;
    double KGamma = K * gamma;
    double BBeta = beta[0] + beta[1];
    double WTau = W * tau;
    double* p = new double[2 * K];
    // when c = 0
    for (int k = 0; k < K; k ++)
    {
        p[k] = (ndz[d][k] + gamma) / (nd_z[d] + KGamma);
        p[k] *= (ndc[d][0] + beta[0]) / (nd_c[d] + BBeta);
        p[k] *= (nzw[k][w] + tau) / (nz_w[k] + WTau);
    }
    // when c = 1
    for (int k = 0; k < K; k ++)
    {
        p[K + k] = (nfz[f][k] + alpha) / (nf_z[f] + KAlpha);
        p[K + k] *= (ndc[d][1] + beta[1]) / (nd_c[d] + BBeta);
        p[K + k] *= (nzw[k][w] + tau) / (nz_w[k] + WTau);
    }
    // cumulate multinomial parameters
    for (int k = 1; k < 2 * K; k++) 
	    p[k] += p[k - 1];
    // scaled sample because of unnormalized p[]
    double u = ((double) random() / RAND_MAX) * p[2 * K - 1];

    int topic = 0;
    for (topic = 0; topic < 2 * K - 1; topic++)
	    if (p[topic] > u)
	        break;
    //printf("%.3lf %.3lf %d\n", p[K - 1], u, topic);
    delete[] p;
    return make_pair(topic / K, topic % K);
}

int         Model::Train(int maxIter, int BURN_IN, int SAMPLE_LAG)
{
    printf("Start learning!\n");
    InitEstimation();
    int sample_cnt = 0;
    for (int iter = 0; iter < maxIter; iter ++)
    {
        printf("[Iteration %d]...\n", iter + 1);
        for (int d = 0; d < D; d ++)
        {
            Document* doc = corpus -> docs[d];
            int a = doc -> authorId;
            int fig = doc -> figId;
            for (unsigned int i = 0; i < doc -> words.size(); i ++)
            {
                int w = doc -> words[i];
                int old_z = Z[d][i];
                int old_c = C[d][i];
                nzw[old_z][w] --;
                nz_w[old_z] --;
                ndc[d][old_c] --;
                nd_c[d] --;
                if (old_c == 0)
                {
                    ndz[d][old_z] --;
                    nd_z[d] --;
                }
                else
                {
                    nfz[fig][old_z] --;
                    nf_z[fig] --;
                }
                pair<int, int> s = SampleTopic(d, a, w, fig);
                int c = s.first;
                int z = s.second;
                //printf("%d : %d %d\n", d, c, z);
                C[d][i] = c;
                Z[d][i] = z;
                nzw[z][w] ++;
                nz_w[z] ++;
                ndc[d][c] ++;
                nd_c[d] ++;
                if (c == 0)
                {
                    ndz[d][z] ++;
                    nd_z[d] ++;
                }
                else
                {
                    nfz[fig][z] ++;
                    nf_z[fig] ++;
                }
            }
        }
        //printf("%d\n", iter);
        for (int f = 0; f < M; f ++)
        {
            Figure* fig = corpus -> figs[f];
            for (int t = 0; t < T; t ++)
            {
                double x = fig -> features[t];
                int old_e = E[f][t];
                nfz[f][old_e] --;
                nf_z[f] --;
                int e = SampleEmotion(x, t, f);
                //printf("%d %d\n", f, e);
                E[f][t] = e;
                nfz[f][e] ++;
                nf_z[f] ++;
                
                // update delta & mu
                delta[old_e][t] = pow(delta[old_e][t], 2) * nz_t[old_e][t];
                delta[old_e][t] -= x * x;
                delta[old_e][t] += 2 * mu[old_e][t] * sumz_t[old_e][t];
                delta[old_e][t] -= pow(mu[old_e][t], 2) * nz_t[old_e][t];
                
                if (nz_t[old_e][t] == 0)
                    printf("big error!\n");
                if (nz_t[old_e][t] == 1)
                    mu[old_e][t] = 0;
                else
                    mu[old_e][t] = (mu[old_e][t] * nz_t[old_e][t] - x) / (nz_t[old_e][t] - 1);
                
                nz_t[old_e][t] --;
                sumz_t[old_e][t] -= x;
                
                delta[old_e][t] -= 2 * mu[old_e][t] * sumz_t[old_e][t];
                delta[old_e][t] += pow(mu[old_e][t], 2) * nz_t[old_e][t];
                
                if (delta[old_e][t] < 0)
                {
                    printf("%.5lf %.5lf %d\n", mu[old_e][t], sumz_t[old_e][t], nz_t[old_e][t]);
                    printf("Error!\n");
                }
                
                if (nz_t[old_e] == 0)
                    delta[old_e][t] = 0;
                else
                    delta[old_e][t] = sqrt(delta[old_e][t] / (nz_t[old_e][t] + 0.0));
                
                delta[e][t] = pow(delta[e][t], 2) * nz_t[e][t];
                delta[e][t] += x * x;
                delta[e][t] += 2 * mu[e][t] * sumz_t[e][t];
                delta[e][t] -= pow(mu[e][t], 2) * nz_t[e][t];
                
                mu[e][t] = (mu[e][t] * nz_t[e][t] + x) / (nz_t[e][t] + 1);
                
                nz_t[e][t] ++;
                sumz_t[e][t] += x;
                
                delta[e][t] -= 2 * mu[e][t] * sumz_t[e][t];
                delta[e][t] += pow(mu[e][t], 2) * nz_t[e][t];
                
                if (delta[e][t] < 0)
                    printf("Error !!!\n");
                
                delta[e][t] = sqrt(delta[e][t] / nz_t[e][t]);
            }
        }

        if (iter < BURN_IN)
            continue;
        if ((iter - BURN_IN) % SAMPLE_LAG != 0)
            continue;
        sample_cnt ++;
        // update parameters
        for (int d = 0; d < D; d ++)
        {
            double sum = 0.0;
            for (int k = 0; k < K; k ++)
            {
                pzd[k][d] = ndz[d][k] + gamma;
                sum += pzd[k][d];
            }
            for (int k = 0; k < K; k ++)
            {
                if (sum > 0)
                    pzd[k][d] /= sum;
                else
                    pzd[k][d] = 1.0 / K;
                s_pzd[k][d] += pzd[k][d];
            }
        }
        for (int f = 0; f < M; f ++)
        {
            double sum = 0.0;
            for (int k = 0; k < K; k ++)
            {
                pzf[k][f] = nfz[f][k] + alpha;
                sum += pzf[k][f];
            }
            for (int k = 0; k < K; k ++)
            {
                if (sum > 0)
                    pzf[k][f] /= sum;
                else
                    pzf[k][f] = 1.0 / K;
                s_pzf[k][f] += pzf[k][f];
            }
        }
        for (int k = 0; k < K; k ++)
        {
            double sum = 0.0;
            for (int w = 0; w < W; w ++)
            {
                pwz[w][k] = nzw[k][w] + tau;
                sum += pwz[w][k];
            }
            for (int w = 0; w < W; w ++)
            {
                if (sum > 0)
                    pwz[w][k] /= sum;
                else
                    pwz[w][k] = 1.0 / W;
                s_pwz[w][k] += pwz[w][k];
            }
        }
        for (int d = 0; d < D; d ++)
        {
            double sum = 0.0;
            for (int c = 0; c < 2; c ++)
            {
                pcd[c][d] = ndc[d][c] + beta[c];
                sum += pcd[c][d];
            }
            for (int c = 0; c < 2; c ++)
            {
                if (sum > 0)
                    pcd[c][d] /= sum;
                else
                    pcd[c][d] = 0.5;
                s_pcd[c][d] += pcd[c][d];
            }
        }
        for (int k = 0; k < K; k ++)
        {
            for (int t = 0; t < T; t ++)
            {
                s_mu[k][t] += mu[k][t];
                s_delta[k][t] += delta[k][t];
            }
        }
    }
    for (int d = 0; d < D; d ++)
    {
        for (int c = 0; c < 2; c ++)
            pcd[c][d] = s_pcd[c][d] / (sample_cnt + 0.0);
        for (int z = 0; z < K; z ++)
            pzd[z][d] = s_pzd[z][d] / (sample_cnt + 0.0);
    }
    for (int f = 0; f < M; f ++)
    {
        for (int z = 0; z < K; z ++)
            pzf[z][f] = s_pzf[z][f] / (sample_cnt + 0.0);
    }
    for (int z = 0; z < K; z ++)
    {
        for (int w = 0; w < W; w ++)
        {
            pwz[w][z] = s_pwz[w][z] / (sample_cnt + 0.0);
            if (pwz[w][z] > 1)
                printf("%.5lf %d %d\n", pwz[w][z], w, z);
        }
    }
    for (int z = 0; z < K; z ++)
    {
        for (int t = 0; t < T; t ++)
        {
            mu[z][t] = s_mu[z][t] / (sample_cnt + 0.0);
            delta[z][t] = s_delta[z][t] / (sample_cnt + 0.0);
        }
    }
    return 0;
}

double      Random()
{
    return 1.0 * rand() / RAND_MAX;
}

int         Model::InitEstimation()
{
    s_pcd = new double*[2];
    s_pzd = new double*[K];
    s_pzf = new double*[K];
    s_pwz = new double*[W];
    s_mu = new double*[K];
    s_delta = new double*[K];
    pcd = new double*[2];
    pzd = new double*[K];
    pwz = new double*[W];
    pzf = new double*[K];
    nzw = new int*[K];
    ndz = new int*[D];
    nd_z = new int[D];
    nfz = new int*[M];
    nf_z = new int[M];
    ndc = new int*[D];
    nd_c = new int[D];
    nzw = new int*[K];
    nz_w = new int[K];
    nz_t = new int*[K];
    sumz_t = new double*[K];
    mu = new double*[K];
    delta = new double*[K];
    Z = new int*[D];
    C = new int*[D];
    E = new int*[M];

    for (int c = 0; c < 2; c ++)
    {
        pcd[c] = new double[D];
        s_pcd[c] = new double[D];
        for (int d = 0; d < D; d ++)
            s_pcd[c][d] = 0.0;
    }
    for (int d = 0; d < D; d ++)
        ndz[d] = new int[K];
    for (int k = 0; k < K; k ++)
    {
        nz_t[k] = new int[T];
        sumz_t[k] = new double[T];
        pzd[k] = new double[D];
        pzf[k] = new double[M];
        s_pzd[k] = new double[D];
        s_pzf[k] = new double[M];
        for (int d = 0; d < D; d ++)
            s_pzd[k][d] = 0.0;
        for (int m = 0; m < M; m ++)
            s_pzf[k][m] = 0.0;
        nzw[k] = new int[W];
        delta[k] = new double[T];
        mu[k] = new double[T];
        s_mu[k] = new double[T];
        s_delta[k] = new double[T];
        for (int t = 0; t < T; t ++)
        {
            s_mu[k][t] = 0.0;
            s_delta[k][t] = 0.0;
        }
    }
    for (int w = 0; w < W; w ++)
    {
        pwz[w] = new double[K];
        s_pwz[w] = new double[K];
        for (int k = 0; k < K; k ++)
            s_pwz[w][k] = 0.0;
    }
    for (int d = 0; d < D; d ++)
    {
        ndc[d] = new int[2];
        Z[d] = new int[corpus -> docs[d] -> words.size()];
        C[d] = new int[corpus -> docs[d] -> words.size()];
    }
    for (int f = 0; f < M; f ++)
    {
        nfz[f] = new int[K];
        E[f] = new int[T];
    }

    srandom(745623); // initialize for random number generation
    for (int d = 0; d < D; d ++)
    {
        nd_z[d] = 0;
        for (int k = 0; k < K; k ++)
            ndz[d][k] = 0;
    }
    for (int f = 0; f < M; f ++)
    {
        nf_z[f] = 0;
        for (int k = 0; k < K; k ++)
            nfz[f][k] = 0;
    }
    for (int d = 0; d < D; d ++)
    {
        nd_c[d] = 0;
        for (int c = 0; c < 2; c ++)
            ndc[d][c] = 0;
    }
    for (int k = 0; k < K; k ++)
    {
        for (int t = 0; t < T; t ++)
        {
            sumz_t[k][t] = 0.0;
            nz_t[k][t] = 0;
            mu[k][t] = 0.0;
        }
        nz_w[k] = 0;
        for (int w = 0; w < W; w ++)
            nzw[k][w] = 0;
    }
    for (int d = 0; d < D; d ++)
    {
        Document* doc = corpus -> docs[d];
        int f = doc -> figId;
        for (unsigned int i = 0; i < doc -> words.size(); i ++)
        {
            int w = doc -> words[i];
            double p = Random();
            int c = 1;
            if (p <= (beta[0] + 1e-5) / (beta[0] + beta[1] + 2 * 1e-5))
                c = 0;
            int k = (int) (Random() * K);
            if (k == K)
                k --;
            C[d][i] = c;
            Z[d][i] = k;
            if (c == 0)
            {
                ndz[d][k] ++;
                nd_z[d] ++;
            }
            else
            {
                nfz[f][k] ++;
                nf_z[f] ++;
            }
            nzw[k][w] ++;
            nz_w[k] ++;
            ndc[d][c] ++;
            nd_c[d] ++;
        }
    }
    for (int f = 0; f < M; f ++)
    {
        Figure* fig = corpus -> figs[f];
        for (int t = 0; t < T; t ++)
        {
            double x = fig -> features[t];
            int k = (int) (Random() * K);
            if (k == K)
                k --;
            mu[k][t] += x;
            E[f][t] = k;
            nfz[f][k] ++;
            nf_z[f] ++;
            nz_t[k][t] ++;
            sumz_t[k][t] += x;
        }
    }
    for (int t = 0; t < T; t ++)
    {
        for (int k = 0; k < K; k ++)
        {
            mu[k][t] /= (nz_t[k][t] + 0.0);
            delta[k][t] = 0.0;
        }
    }
    for (int f = 0; f < M; f ++)
    {
        for (int t = 0; t < T; t ++)
        {
            double x = corpus -> figs[f] -> features[t];
            int k = E[f][t];
            delta[k][t] += pow((x - mu[k][t]), 2);
        }
    }
    for (int t = 0; t < T; t ++)
    {
        for (int k = 0; k < K; k ++)
        {
            delta[k][t] /= nz_t[k][t];
            delta[k][t] = sqrt(delta[k][t]);
        }
    }
    return 0;
}

int         Model::SaveTopic(const char* fileDir, int top)
{
    printf("Saving topics to %s...\n", fileDir);
    bool done[W];
    FILE* fout = fopen(fileDir, "w");
    int hit[K][top];
    memset(hit, 0, sizeof(hit));
    for (int k = 0; k < K; k ++)
    {
        fprintf(fout, "Topic #%d:\n", k);
        memset(done, false, sizeof(done));
        for (int t = 0; t < top; t ++)
        {
            double max = 0;
            int wid;
            for (int w = 0; w < W; w ++)
            {
                if (pwz[w][k] > max && (! done[w]))
                {
                    max = pwz[w][k];
                    wid = w;
                }
            }
            done[wid] = true;
            //printf("%.5lf\n", max);
            fprintf(fout, "%s %.5lf\n", corpus -> terms[wid].c_str(), max);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);

    return 0;
}

int         Model::SaveGaussian(const char* fileDir)
{
    FILE* fout = fopen(fileDir, "w");
    fprintf(fout, "Mu:\n");
    for (int k = 0; k < K; k ++)
    {
        for (int t = 0; t < T; t ++)
        {
            fprintf(fout, "%.5lf ", mu[k][t]);
        }
        fprintf(fout, "\n");
    }
    fprintf(fout, "Delta:\n");
    for (int k = 0; k < K; k ++)
    {
        for (int t = 0; t < T; t ++)
        {
            fprintf(fout, "%.5lf ", delta[k][t]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

int         Model::SavePzf(const char* fileDir)
{
    printf("Save topic distribution to %s.\n", fileDir);
    FILE* fout = fopen(fileDir, "w");
    for (int m = 0; m < M; m ++)
    {
        fprintf(fout, "%s %d", corpus -> figs[m] -> name.c_str(), corpus -> figs[m] -> label);
        for (int z = 0; z < K; z ++)
        {
            fprintf(fout, " %.5lf", pzf[z][m]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

int         Model::SavePzd(const char* fileDir)
{
    printf("Save topic distribution to %s.\n", fileDir);
    FILE* fout = fopen(fileDir, "w");
    for (int d = 0; d < D; d ++)
    {
        for (int k = 0; k < K; k ++)
        {
            fprintf(fout, "%.5lf ", pzd[k][d]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

int         Model::SavePcd(const char* fileDir)
{
    printf("Save topic distribution to %s.\n", fileDir);
    FILE* fout = fopen(fileDir, "w");
    for (int d = 0; d < D; d ++)
    {
        Document* doc = corpus -> docs[d];
        for (unsigned int i = 0; i < doc -> words.size(); i ++)
        {
            fprintf(fout, "%s ", corpus -> terms[doc -> words[i]].c_str());
        }
        fprintf(fout, "\n");
        for (int c = 0; c < 2; c ++)
            fprintf(fout, " %.5lf", pcd[c][d]);
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

int         Model::GenerateInstance(const char* fileDir)
{
    FILE* fout = fopen(fileDir, "w");
    int posCnt = 0;
    int negCnt = 0;
    for (int f = 0; f < M; f ++)
    {
        int label = corpus -> figs[f] -> label;
        if (label != -1)
            posCnt ++;
        else
            negCnt ++;
    }
    int trainNeg = 0;
    int trainPos = 0;
    int negIns = 0;
    for (int f = 0; f < M; f ++)
    {
        int label = corpus -> figs[f] -> label;
        int train = 0;
        if (label == -1)
        {
            if (negIns > 3000)
                continue;
            if (trainNeg < posCnt * 0.5)
            {
                trainNeg ++;
                train = 1;
            }
            negIns ++;
        }
        else
        {
            if (trainPos < posCnt * 0.5)
            {
                train = 1;
                trainPos ++;
            }
        }
        if (train == 0)
            fprintf(fout, "?");
        else
            fprintf(fout, "+");
        if (label == -1)
            fprintf(fout, "0");
        else
            fprintf(fout, "1");
        //Figure* fig = corpus -> figs[f];
        //for (int t = 0; t < T; t ++)
        //    fprintf(fout, " feature%d:%.5lf", t, fig -> features[t]);
        for (int k = 0; k < K; k ++)
        {
            fprintf(fout, " topic%d:%.5lf", k, pzf[k][f]);
        }
        fprintf(fout, "\n");
    }
    printf("#Postive instance: %d\n#Negative instance: %d\n", posCnt, negCnt);
    fclose(fout);
    return 0;
}
