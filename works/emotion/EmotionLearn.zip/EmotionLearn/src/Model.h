#pragma once

#include "DataSet.h"

#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <set>

using namespace std;

class   Model 
{
public:
    int             D; // #docs
    int             M; // #figs
    int             W; // #terms
    int             A; // #authors
    int             K; // #toipics
    int             T;
    double          alpha;
    double*         beta;
    double          gamma;
    double          tau;
    double**        pcd;
    double**        pzd;
    double**        pzf;
    double**        pwz;
    double**        mu;
    double**        delta;

    double**        s_pcd;
    double**        s_pzd;
    double**        s_pzf;
    double**        s_pwz;
    double**        s_mu;
    double**        s_delta;
    
    double*         sum_pwz;

    int**           ndz;
    int*            nd_z;
    int**           nfz;
    int*            nf_z;
    int**           ndc;
    int*            nd_c;
    int**           nzw;
    int*            nz_w;

    int**           nz_t;
    double**        sumz_t;
    int**           Z;
    int**           C;
    int**           E;

    Corpus*         corpus;

    pair<int, int>  SampleTopic(int d, int a, int w, int f);
    int             SampleEmotion(double x, int t, int f);
    int             Train(int maxIter, int BURN_IN, int SAMPLE_LAG);
    int             SavePzf(const char* fileDir);
    int             SaveTopic(const char* fileDir, int top);
    int             InitEstimation();
    int             SaveGaussian(const char* fileDir);
    int             SavePcd(const char* fileDir);
    int             SavePzd(const char* fileDir);
    int             GenerateInstance(const char* fileDir);
    Model(Corpus* corpus);
};
