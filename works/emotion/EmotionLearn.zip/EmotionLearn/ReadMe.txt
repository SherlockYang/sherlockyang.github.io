Latent Emotion Learning Method v0.1                                 
     by Yang Yang, Tsinghua University                              
                                                                    
Usage: emotion -data [options]                                      
options include -stopword -topic -b0 -b1 -iter                      

   -input       string      : data file direction                   
   -stopword    string      : stopwrod file direction               
   -topic       int         : topic number                          
   -b0          double      : parameter of Beta, 10.0 as default    
   -b1          double      : parameter of Beta, 5.0 as default     
   -iter        int         : number of iterations, 100 as default  
   
<Input>

ImageID EmotionLabel VisualFeature1 VisualFeature2 ... VisualFeatureN
#Comments
CommentTime
CommentUserID
(we separate terms in the comments into nouns and adjectives. Present nouns first)
Noun1 Noun2 ...
Adjective1 Adjective2 ...
0/1 (the user posting the image follows the user leaving the comments (1) or not (0)) 0/1 (the user leaving the comment follows the user posting the image (1) or not (0)) 

<Output>

output/gaussian     :   Gaussian parameters under each label, learned by our model
output/topic        :   topics extracted from comments
output/pzd          :   P(z | comment)
output/pzf          :   P(z | image)
output/pcd          :   P(c | comment)

