#pragma once

#include <string>
#include <vector>
#include <map>
#include <set>
#include <utility>

using std::string;
using std::vector;
using std::map;
using std::make_pair;
using std::istringstream;
using std::stringstream;

class   Util
{
public:
    static string Num2Str(double num);
    static vector<string> StringTokenize(string line);
    static vector<string> StringSplit(string line, char separator);
    static int String2Int(string str);
    static int GetOrInsertId(map<int, int> dict, const int key);
    static int GetOrInsertId(map<string, int> dict, const string& key);
    static int GetId(map<int, int> dict, const int key);
    static int GetId(map<string, int> dict, const string& key);
};
