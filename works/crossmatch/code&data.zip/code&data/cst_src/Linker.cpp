#include "Linker.h"

bool            cmprank(pair<int, double> a, pair<int, double> b)
{
    return a.second > b.second;
}

bool            Linker::HasLink(int doc1, int doc2)
{
    int D = dataSet -> corpus -> docNum;
    if (linkSet.count(doc1 * D + doc2) > 0 || linkSet.count(doc2 * D + doc1) > 0)
        return true;
    return false;
}

int             Linker::BuildDataSet(const char* dataFile, const char* wordFile)
{
    dataSet = new DataSet();
    dataSet -> ReadCorpus(dataFile);
    dataSet -> ReadWordList(wordFile);
    
    linkSet.clear();
    int D = dataSet -> corpus -> docNum;
    for (int i = 0; i < D; i ++)
    {
        Document* doc = dataSet -> corpus -> docs[i];
        for (unsigned int j = 0; j < doc -> links.size(); j ++)
        {
            int key = i * D + doc -> links[j];
            linkSet.insert(key);
        }
    }

    /*
    for (int d = 0; d < D; d ++)
    {
        Document* doc = dataSet -> corpus -> docs[d];
        if (doc -> source == 1 || doc -> links.size() == 0)
            continue;
        printf("%s ", doc -> title.c_str());
        for (unsigned int i = 0; i < doc -> links.size(); i ++)
        {
            printf("%s ", dataSet -> corpus -> docs[doc -> links[i]] -> title.c_str());
        }
        printf("\n");
    }
    */
    return 0;
}

void            Linker::SetAlpha(double alpha)
{
    this -> alpha = alpha;
}

void            Linker::SetBeta(double beta)
{
    this -> beta = beta;
}

void            Linker::SetGamma(double* gamma)
{
    this -> gamma = gamma;
}

int             Linker::ModelCorpus(int topicNum, int maxIter, int model, const char* topicFile)
{
    if (model == 0)
    {
        lda = new LDA(topicNum, dataSet -> corpus, alpha, beta);
        lda -> Estimation(maxIter);
        lda -> SaveTopic("lda_topic_view.out", 100);
        lda -> SaveTopicDis(topicFile);
    } 
    else 
    {
        dwt = new DWT(topicNum, dataSet -> corpus, alpha, beta, gamma);
        dwt -> Estimation(maxIter);
        dwt -> SaveTopic("cst_topic_view.out", 100);
        dwt -> SaveTopicDis(topicFile);
    }
    printf("Copus has been modeled!\n");

    printf("#topic: %d, #iter: %d, ", topicNum, maxIter);
    vector<string> title;
    vector<double> test;
    vector<double> train;
    double allTest = 0;
    int countTest = 0;
    double allTrain = 0;
    int countTrain = 0;
    for (int d = 0; d < dataSet -> corpus -> docNum; d ++)
    {
        Document* doc = dataSet -> corpus -> docs[d];
        if (doc -> source == 1 || doc -> tests.size() == 0)
            continue;
        title.push_back(doc -> title);
        double sim = 0;
        printf("%d %d\n", d, (int) doc -> tests.size());
        for (unsigned int i = 0; i < doc -> tests.size(); i ++)
        {
            int s = doc -> tests[i];
            if (model == 0)
                sim += lda -> DocSimilarity(d, s);
            else
                sim += dwt -> DocSimilarity(d, s);
            countTest ++;
        }

        allTest += sim;
        test.push_back(sim / doc -> tests.size());
        sim = 0;
        for (unsigned int i = 0; i < doc -> links.size(); i ++)
        {
            int s = doc -> links[i];
            if (model == 0)
                sim += lda -> DocSimilarity(d, s);
            else
                sim += dwt -> DocSimilarity(d, s);
            countTrain ++;
        }
        allTrain += sim;
        if (doc -> links.size() > 0)
            train.push_back(sim / doc -> links.size());
        //printf("%s %.5lf\n", doc -> title.c_str(), sim / doc -> tests.size());
    }
    /*
    printf("#Test: %d, #Train: %d\n", countTest, countTrain);
    printf("Test: %.5lf, Train: %.5lf\n", allTest / countTest, allTrain / countTrain);
    for (unsigned int i = 0; i < title.size(); i ++)
    {
        printf("%s test:%.5lf train:%.5lf\n", title[i].c_str(), test[i],
        train[i]);
    }
    */
    return 0;
}

void            Linker::SaveStandardLinks(const char* ansFile)
{
    FILE* fout = fopen(ansFile, "w");
    for (int d1 = 0; d1 < (int) dataSet -> corpus -> docNum; d1 ++)
    {
        for (int d2 = d1 + 1; d2 < (int) dataSet -> corpus -> docNum; d2 ++)
        {
            if (! HasLink(d1, d2))
                continue;
            Document* doc1 = dataSet -> corpus -> docs[d1];
            Document* doc2 = dataSet -> corpus -> docs[d2];
            fprintf(fout, "%s;%s\n", doc1 -> title.c_str(), doc2 -> title.c_str());
        }
    }

    fclose(fout);
    printf("Save answers in %s\n", ansFile);
}

void            Linker::ModelSimilarity(const char* linkFile)
{
    FILE* fout = fopen(linkFile, "w");
    double max = 0;
    for (int d1 = 0; d1 < (int) dataSet -> corpus -> docNum; d1 ++)
    {
        for (int d2 = d1 + 1; d2 < (int) dataSet -> corpus -> docNum; d2 ++)
        {
            double simi = lda -> DocSimilarity(d1, d2);
            if (max < simi)
                max = simi;
        }
    }
    for (int d1 = 0; d1 < (int) dataSet -> corpus -> docNum; d1 ++)
    {
        for (int d2 = d1 + 1; d2 < (int) dataSet -> corpus -> docNum; d2 ++)
        {
            Document* doc1 = dataSet -> corpus -> docs[d1];
            Document* doc2 = dataSet -> corpus -> docs[d2];
            fprintf(fout, "%s;%s;%.5lf\n", doc1 -> title.c_str(), doc2 ->
            title.c_str(), 1 - lda -> DocSimilarity(d1, d2) / max);
        }
    }

    fclose(fout);
    printf("Save similarity between docs in %s\n", linkFile);
}

void            Linker::Link(int model)
{
    int testCount = 0;
    double map = 0;
    int testProd = 0;
    int totalHit = 0;
    double aveRank = 0;
    double mrr = 0;
    int D = dataSet -> corpus -> docNum;
    int P[D + 1];
    double R[D + 1];
    for (int i = 0; i < D + 1; i ++)
    {
        P[i] = 0;
        R[i] = 0.0;
    }
    for (int d1 = 0; d1 < dataSet -> corpus -> docNum; d1 ++)
    {
        Document* doc1 = dataSet -> corpus -> docs[d1];
        if (doc1 -> source == 1 || doc1 -> tests.size() == 0)
            continue;
        testCount += doc1 -> tests.size();
        testProd ++;
        vector<pair<int, double> > ranks;
        for (int d2 = 0; d2 < dataSet -> corpus -> docNum; d2 ++)
        {
            Document* doc2 = dataSet -> corpus -> docs[d2];
            if (doc2 -> source == 0)
                continue;
            bool find = false;
            for (unsigned int i = 0; i < doc1 -> links.size(); i ++)
                if (doc1 -> links[i] == d2)
                {
                    find = true;
                    break;
                }
            if (find)
                continue;
            if (model == 0)
                ranks.push_back(make_pair(d2, lda -> DocSimilarity(d1, d2)));
            else
                ranks.push_back(make_pair(d2, dwt -> DocSimilarity(d1, d2)));
            //printf("%.5lf\n", ranks[ranks.size() - 1].second);
        }
        sort(ranks.begin(), ranks.end(), cmprank);
        int hit = 0;
        double ap = 0;
        int totalRank = 0;
        for (unsigned int i = 0; i < ranks.size(); i ++)
        {
            bool find = false;
            for (unsigned int j = 0; j < doc1 -> tests.size(); j ++)
                if (doc1 -> tests[j] == ranks[i].first)
                {
                    find = true;
                    break;
                }
            if (find)
            {
                P[i + 1] ++;
                mrr += 1.0 / (i + 1);
                hit ++;
                ap += (hit + 0.0) / (i + 1);
                totalRank += i + 1;
            }
            R[i + 1] += (hit + 0.0) / doc1 -> tests.size();
        }
        aveRank += (totalRank + 0.0) / doc1 -> tests.size();
        totalHit += hit;
        ap /= doc1 -> tests.size();
        map += ap;
    }
    for (int i = 1; i < D + 1; i ++)
    {
        P[i] += P[i - 1];
        R[i] = R[i] / testProd;
    }
    aveRank /= testProd;
    map /= testProd;
    mrr /= testCount;
    //printf("#tests: %d\n", testCount);
    printf("P@3   P@5   P@10   P@20\n"); 
    printf("%.3lf %.3lf %.3lf %.3lf\n", 
    (P[3] + 0.0) / (3 * testProd), (P[5] + 0.0) / (5 * testProd), 
    (P[10] + 0.0) / (10 * testProd), (P[20] + 0.0) / (20 * testProd));

    printf("R@3   R@5   R@10   R@20\n"); 
    printf("%.3lf %.3lf %.3lf %.3lf\n", 
    R[3] / testProd, R[5] / testProd, R[10] / testProd, R[20] / testProd);

    printf("#Hits: %d    Average Rank: %.3lf     MAP: %.5lf     MRR: %.5lf\n", totalHit, aveRank, map, mrr);
}

int             Linker::Evaluate(vector<Label*> results)
{
    //printf("Start to validify the results!\n");
    int tp = 0;
    int fp = 0;
    int tn = 0;
    int fn = 0;
    for (unsigned int i = 0; i < results.size(); i ++)
    {
        Label* label = results[i];
        //printf("%d\n", i);
        if (label -> label == 1)
        {
            if (HasLink(label -> doc1, label -> doc2))
            {
                tp ++;
                /*
                printf("%s %s %.4lf\n", dataSet -> corpus -> docs[label -> doc1] ->
                title.c_str(), dataSet -> corpus -> docs[label -> doc2] ->
                title.c_str(), label -> weight);
                */
            }
            else
            {
                fp ++;
            }
        }
        else
        {
            if (HasLink(label -> doc1, label -> doc2))
            {
                fn ++;
            }
            else
            {
                tn ++;
            }
        }
    }

    double precision = (tp + 0.0) / (tp + fp);
    double recall = (tp + 0.0) / (tp + fn);
    printf("TP : %d   FP : %d   TN : %d   FN : %d\n", tp, fp, tn, fn);
    printf("Precision: %.4lf\n", precision);
    printf("Recall: %.4lf\n", recall);
    printf("F1 Measure: %.4lf\n", 2 * precision * recall / (precision + recall));
    printf("Accuracy: %.4lf\n", ((tp + tn) + 0.0) / (tp + tn + fp + fn));
    return 0;
}
