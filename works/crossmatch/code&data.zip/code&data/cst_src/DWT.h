#pragma once

#include "DataSet.h"
#include "TopicModel.h"

#define myrand() (double) (((unsigned long) randomMT()) / 4294967296.)
#define NUM_INIT 1

class DWT : public TopicModel 
{
public:
    double          alpha;  // hyparameters of pzd
    double          beta;   // hyparameters of pwz
    double*         gamma;  // hyparameter of pc
    int*            nd;
    int*            nw;
    int*            nc;
    int*            ns;
    int**           nzd;
    int**           nzw;
    vector<int>*    links;
        
    int             InitEstimation(vector<int> **Z, vector<int> **C);
    int             SamplingZ(int w, int c);
    int             SamplingC(int z, int d);
    void            Estimation(int maxIter);
    double          Likelihood();
    vector<int>     CollectLinks(int d);
    
    DWT(int topicNum, Corpus* corpus, double alpha, double beta, double* gamma);
    ~DWT();
};
