#include "Util.h"
#include <sstream>

string          Util::Num2Str(double num)
{
    stringstream ss;
    ss << num;
    return ss.str();
}

int             Util::GetId(map<string, int> dict, const string& key)
{
    map<string, int>::iterator it = dict.find(key);
    if (it != dict.end())
        return it->second;
    else
        return -1;
}

int             Util::GetId(map<int, int> dict, const int key)
{
    map<int, int>::iterator it = dict.find(key);
    if (it != dict.end())
        return it->second;
    else
        return -1;
}


int             Util::GetOrInsertId(map<string, int> dict, const string& key)
{
    map<string, int>::iterator it = dict.find(key);
    if (it != dict.end())
        return it->second;
    else
    {
        int id = dict.size();
        dict.insert(make_pair(key, id));
        return dict.size();
    }
}

int             Util::GetOrInsertId(map<int, int> dict, const int key)
{
    map<int, int>::iterator it = dict.find(key);
    if (it != dict.end())
        return it->second;
    else
    {
        int id = dict.size();
        dict.insert(make_pair(key, id));
        return dict.size();
    }
}

vector<string>  Util::StringTokenize(string line)
{
    istringstream   strin(line);
    vector<string>  result;
    string          token;

    while (strin >> token)
        result.push_back(token);

    return result;
}


vector<string>  Util::StringSplit(string line, char separator)
{
    vector<string>  result;
    line += separator;

    int p = 0;
    for (unsigned int i = 0; i < line.length(); i ++)
        if (line[i] == separator)
        {
            if (i - p > 0) result.push_back( line.substr(p, i-p) );
            p = i + 1;
        }

    return result;
}

int             Util::String2Int(string str)
{
    int result = 0;
    for (unsigned int i = 0; i < str.length(); i ++)
    {
        if (str[i] >= '0' && str[i] <= '9')
            result = result * 10 + (str[i] - '0');
        else
        {
            printf("Error when formating string to integer!\n");
            return -1;
        }
    }
    return result;
}
