#pragma once

#include "DataSet.h"

#include <string>
#include <vector>
#include <map>

using std::string;
using std::vector;
using std::map;

class PreProcessor
{
public:
    static vector<Document*>    ReadWikiFromFile(const char* dataFile);
    static vector<Document*>    ReadPatentFromFile(const char* dataFile);
    static int                  ReadAnswerFromFile(const char *fileDir, vector<Document*> docList, int test);
    static void                 WriteToFile(const char* file_dir, vector<Document*> docList);
    static void                 ReadStopWords(const char* file); 
};

