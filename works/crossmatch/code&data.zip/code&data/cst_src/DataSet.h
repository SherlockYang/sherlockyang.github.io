#pragma once

#include "Util.h"

#include <string>
#include <vector>
#include <map>

using std::string;
using std::vector;
using std::map;

class Document 
{
public:
    int                 id;
    int                 source;
    string              title;
    vector<int>         counts;
    vector<int>         words;
    vector<int>         links;
    vector<int>         tests;
};

class Corpus
{
public:
    int                 docNum;
    int                 wordNum;
    int                 linkNum;
    vector<Document*>   docs; // docs[i]: doc with id = i
    vector<string>      wordList;
    
    void                Clear();
    Corpus();
};

class Label
{
public:
    int                 doc1;
    int                 doc2;
    int                 label;
    double              weight;
};

class DataSet
{
public:
    Corpus*             corpus;
    int                 ReadCorpus(const char* inputFile);
    int                 ReadWordList(const char* inputFile);
    DataSet();
};
