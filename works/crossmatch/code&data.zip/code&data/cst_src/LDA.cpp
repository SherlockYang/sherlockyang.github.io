#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <vector>
#include "LDA.h"

using namespace std;

LDA::LDA(int topicNum, Corpus* corpus, double alpha, double beta)
{
    this -> topicNum = topicNum;
    this -> corpus = corpus;
    this -> alpha = alpha;
    this -> beta = beta;
}

int         LDA::InitEstimation(vector<int> **Z)
{
    int D = corpus -> docs.size();
    int W = corpus -> wordNum;
    int K = topicNum;
    nd = new int[D];
    nw = new int[K];
    nzd = new int*[K];
    nzw = new int*[K];
    for (int d = 0; d < D; d ++)
        nd[d] = 0;
    for (int i = 0; i < K; i ++)
    {
        nw[i] = 0;
        nzd[i] = new int[D];
        nzw[i] = new int[W];
        for (int j = 0; j < D; j ++)
            nzd[i][j] = 0;
        for (int j = 0; j < W; j ++)
            nzw[i][j] = 0;
    }

    srandom(time(0)); // initialize for random number generation
    for (int d = 0; d < D; d ++)
    {
        Document* doc = corpus -> docs[d];
        for (unsigned int iw = 0; iw < doc -> words.size(); iw ++)
        {
            int w = doc -> words[iw];
            for (int i = 0; i < doc -> counts[iw]; i ++)
            {
                int k = (int)(((double) random() / RAND_MAX) * K);
                Z[d][iw].push_back(k);
                nzw[k][w] ++;
                nzd[k][d] ++;
                nw[k] ++;
                nd[d] ++;
            }
        }
    }

    pzd = new double*[K];
    for (int i = 0; i < K; i ++)
        pzd[i] = new double[D];
    pwz = new double*[W];
    for (int i = 0; i < W; i ++)
        pwz[i] = new double[K];
    return 0;
}

int         LDA::Sampling(int w, int d)
{
    int K = topicNum;
    int W = corpus -> wordNum;
    double Wbeta = W * beta;
    double Kalpha = K * alpha;    
    // do multinomial sampling via cumulative method
    double* p = new double[K];
    for (int k = 0; k < K; k++) 
	    p[k] = (nzw[k][w] + beta) / (nw[k] + Wbeta) * 
               (nzd[k][d] + alpha) / (nd[d] + Kalpha);
    // cumulate multinomial parameters
    for (int k = 1; k < K; k++) 
	    p[k] += p[k - 1];
    // scaled sample because of unnormalized p[]
    double u = ((double) random() / RAND_MAX) * p[K - 1];

    int topic = 0;
    for (topic = 0; topic < K - 1; topic++)
	    if (p[topic] > u)
	        break;
    //printf("%.3lf %.3lf %d\n", p[K - 1], u, topic);
    delete[] p;

    return topic;
}

void        LDA::GibbsSampling(int maxIter)
{
    int D = corpus -> docs.size();
    int W = corpus -> wordNum;
    int K = topicNum;
    printf("#Topics: %d\n", K);
    vector<int>** Z = new vector<int>*[D];
    for (int d = 0; d < D; d ++)
        Z[d] = new vector<int>[corpus -> docs[d] -> words.size()];
    InitEstimation(Z);
    //printf("Initialization is Over!\n");

    // burn-in and sampling
    int lastProcess = -1;
    for (int iter = 0; iter < maxIter; iter ++)
    {
        for (int d = 0; d < D; d ++)
        {
            Document* doc = corpus -> docs[d];
            for (unsigned int iw = 0; iw < doc -> words.size(); iw ++)
            {
                int w = doc -> words[iw];
                for (int freq = 0; freq < doc -> counts[iw]; freq ++)
                {
                    int oldK = Z[d][iw][freq];
                    nzd[oldK][d] --;
                    nzw[oldK][w] --;
                    nd[d] --;
                    nw[oldK] --;
                    int k = Sampling(w, d);
                    Z[d][iw][freq] = k;
                    nzd[k][d] ++;
                    nzw[k][w] ++;
                    nd[d] ++;
                    nw[k] ++;
                }
            }
        }
        
        for (int z = 0; z < K; z ++)
        {
            for (int d = 0; d < D; d ++)
                pzd[z][d] = (nzd[z][d] + alpha) / (K * alpha + nd[d]);
            for (int w = 0; w < W; w ++)
                pwz[w][z] = (nzw[z][w] + beta) / (W * beta + nw[z]);
        }
        int process = (iter + 1) * 100 / maxIter;
        if (process > lastProcess)
        {
            /*
            for (unsigned int i = 0; i < corpus -> labels.size(); i ++)
            {
                int w = corpus -> labels[i] -> word;
                if (strcmp(corpus -> wordList[w].c_str(), "formation") != 0)
                    continue;
                printf("%s", corpus -> wordList[w].c_str());
                for (int z = 0; z < K; z ++)
                    printf(" %.5lf", pwz[w][z]);
                printf("\n");
                break;
            }
            */
            printf("Estimating Parameters of LDA: %d%%......\n", process);
            lastProcess = process;
        }
    }

    for (int z = 0; z < K; z ++)
    {
        if (nzd && nzd[z])
            delete nzd[z];
        if (nzw && nzw[z])
            delete nzw[z];
    }
    for (int d = 0; d < D; d ++)
        if (Z && Z[d])
            delete[] Z[d];
    if (nzd)
        delete[] nzd;
    if (nzw)
        delete[] nzw;
    if (Z)
        delete[] Z;
}

void        LDA::Estimation(int maxIter)
{
    printf("LDA: Start Estimation!\n");
    GibbsSampling(maxIter);
    printf("LDA: Estimation is Over!\n########################################\n");
}

LDA::~LDA()
{
    printf("Deleting LDA!\n");
    /*
    if (nzd)
    {
        for (int z = 0; z < topicNum; z ++)
            if (nzd[z])
                delete nzd[z];
        delete[] nzd;
    }
    if (nzw)
    {
        for (int z = 0; z < topicNum; z ++)
            if (nzw[z])
                delete nzw[z];
        delete[] nzw;
    }
    if (nd)
        delete nd;
    if (nw)
        delete nw;
    */

    if (pzd)
    {
        for (int z = 0; z < topicNum; z ++)
            if (pzd[z])
                delete pzd[z];
        delete[] pzd;
    }

    if (pwz)
    {
        for (int w = 0; w < corpus -> wordNum; w ++)
            if (pwz[w])
                delete pwz[w];
        delete[] pwz;
    }

    if (corpus)
        delete corpus;
}
