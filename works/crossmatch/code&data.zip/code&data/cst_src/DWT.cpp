#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <vector>
#include "DWT.h"

using namespace std;

DWT::DWT(int topicNum, Corpus* corpus, double alpha, double beta, double* gamma)
{
    this -> topicNum = topicNum;
    this -> corpus = corpus;
    this -> alpha = alpha;
    this -> beta = beta;
    this -> gamma = gamma;
}

int         DWT::InitEstimation(vector<int> **Z, vector<int> **C)
{
    int D = corpus -> docs.size();
    int W = corpus -> wordNum;
    int K = topicNum;
    nd = new int[D];
    ns = new int[D];
    nw = new int[K];
    nc = new int[D];
    nzd = new int*[K];
    nzw = new int*[K];
    for (int d = 0; d < D; d ++)
    {
        nd[d] = 0;
        nc[d] = 0;
        ns[d] = 0;
    }
    for (int i = 0; i < K; i ++)
    {
        nw[i] = 0;
        nzd[i] = new int[D];
        nzw[i] = new int[W];
        for (int j = 0; j < D; j ++)
            nzd[i][j] = 0;
        for (int j = 0; j < W; j ++)
            nzw[i][j] = 0;
    }

    srandom(time(0)); // initialize for random number generation
    for (int d = 0; d < D; d ++)
    {
        Document* doc = corpus -> docs[d];
        int L = (int) links[d].size();
        for (unsigned int iw = 0; iw < doc -> words.size(); iw ++)
        {
            int w = doc -> words[iw];
            for (int i = 0; i < doc -> counts[iw]; i ++)
            {
                int c = (int)(((double) random() / RAND_MAX) * (1 + gamma[0] / gamma[1]) * L);
                if (c >= L)
                    c = -1;
                int k = (int)(((double) random() / RAND_MAX) * K);
                C[d][iw].push_back(c);
                if (c == -1)
                    ns[d] ++;
                else
                    nc[links[d][c]] ++;
                Z[d][iw].push_back(k);
                nzw[k][w] ++;
                nzd[k][d] ++;
                nw[k] ++;
                nd[d] ++;
            }
        }
    }

    pzd = new double*[K];
    for (int i = 0; i < K; i ++)
        pzd[i] = new double[D];
    pwz = new double*[W];
    for (int i = 0; i < W; i ++)
        pwz[i] = new double[K];
    return 0;
}

vector<int> DWT::CollectLinks(int d)
{
    vector<int> links;
    links.push_back(d);
    int s = d;
    if (corpus -> docs[d] -> links.size() > 0 && corpus -> docs[d] -> source == 1)
        s = corpus -> docs[d] -> links[0];
    if (s != d)
        links.push_back(s);
    for (unsigned int i = 0; i < corpus -> docs[s] -> links.size(); i ++)
    {
        if (corpus -> docs[s] -> links[i] == d)
            continue;
        links.push_back(corpus -> docs[s] -> links[i]);
    }
    return links;
}

int         DWT::SamplingZ(int w, int c)
{
    int K = topicNum;
    int W = corpus -> wordNum;
    double Wbeta = W * beta;
    double Kalpha = K * alpha;    
    // do multinomial sampling via cumulative method
    double* p = new double[K];
    for (int k = 0; k < K; k++) 
	    p[k] = (nzw[k][w] + beta) / (nw[k] + Wbeta) * 
               (nzd[k][c] + alpha) / (nd[c] + Kalpha);

    // cumulate multinomial parameters
    for (int k = 1; k < K; k++) 
	    p[k] += p[k - 1];
    // scaled sample because of unnormalized p[]
    double u = ((double) random() / RAND_MAX) * p[K - 1];

    int topic = 0;
    for (topic = 0; topic < K - 1; topic++)
	    if (p[topic] > u)
	        break;
    //printf("%.3lf %.3lf %d\n", p[K - 1], u, topic);
    delete[] p;

    return topic;
}

int         DWT::SamplingC(int z, int d)
{
    int K = topicNum;
    // find associated documents
    int L = links[d].size();
    double *p = new double[L + 1];
    double Lgamma = gamma[0] + (L - 1) * gamma[1];
    double allnc = 0;
    double allns = 0;
    double Kalpha = alpha * K;
    double allnzd = 0;
    double allnd = 0;
    for (int c = 0; c < L; c ++)
    {
        if (links[d][c] != d)
            allnc += nc[links[d][c]];
        else
            allns += ns[d];
        allnzd += nzd[z][links[d][c]];
        allnd += nd[links[d][c]];
    }
    for (int c = 0; c < L; c ++)
    {
        p[c] = (nc[links[d][c]] + gamma[1]) / (allnc + gamma[1] * L + gamma[0] + allns) *
               (nzd[z][links[d][c]] + alpha) / (nd[links[d][c]] + Kalpha);
    }
    p[L] = (allns + gamma[0]) / (allnc + allns + Lgamma) *
           (allnzd + alpha) / (allnd + Kalpha);

    // cumulate multinomial parameters
    for (int c = 1; c < L + 1; c++) 
	    p[c] += p[c - 1];
    // scaled sample because of unnormalized p[]
    double u = ((double) random() / RAND_MAX) * p[L];

    int res;
    for (res = 0; res < L; res ++)
	    if (p[res] > u)
	        break;
    //printf("%.3lf %.3lf %d\n", p[K - 1], u, topic);
    delete[] p;
    if (res == L)
        return -1;
    return res;
}

void        DWT::Estimation(int maxIter)
{
    printf("CST: Start Estimation!\n");
    int D = corpus -> docs.size();
    int W = corpus -> wordNum;
    int K = topicNum;
    printf("#Topics: %d\n", K);
    vector<int>** Z = new vector<int>*[D];
    for (int d = 0; d < D; d ++)
        Z[d] = new vector<int>[corpus -> docs[d] -> words.size()];
    vector<int>** C = new vector<int>*[D];
    for (int d = 0; d < D; d ++)
        C[d] = new vector<int>[corpus -> docs[d] -> words.size()];
    links = new vector<int>[D];
    for (int d = 0; d < D; d ++)
        links[d] = CollectLinks(d);
    InitEstimation(Z, C);
    //printf("Initialization is Over!\n");

    // burn-in and sampling
    int lastProcess = -1;
    for (int iter = 0; iter < maxIter; iter ++)
    {
        for (int d = 0; d < D; d ++)
        {
            Document* doc = corpus -> docs[d];
            for (unsigned int iw = 0; iw < doc -> words.size(); iw ++)
            {
                int w = doc -> words[iw];
                for (int freq = 0; freq < doc -> counts[iw]; freq ++)
                {
                    int oldK = Z[d][iw][freq];
                    int oldC = C[d][iw][freq];
                    if (oldC == -1)
                        ns[d] --;
                    else
                        nc[oldC] --;
                    int c = SamplingC(oldK, d);
                    C[d][iw][freq] = c;
                    if (c == -1)
                        ns[d] ++;
                    else
                        nc[c] ++;
                    nzd[oldK][d] --;
                    nzw[oldK][w] --;
                    nd[d] --;
                    nw[oldK] --;
                    int k = SamplingZ(w, c);
                    Z[d][iw][freq] = k;
                    nzd[k][d] ++;
                    nzw[k][w] ++;
                    nd[d] ++;
                    nw[k] ++;
                }
            }
        }
        
        for (int z = 0; z < K; z ++)
        {
            for (int d = 0; d < D; d ++)
            {
                int ndSum = 0;
                int nzdSum = 0;
                for (unsigned int i = 0; i < links[d].size(); i ++)
                {
                    int s = links[d][i];
                    ndSum += nd[s] + K * alpha;
                    nzdSum += nzd[z][s] + alpha;
                }
                pzd[z][d] = (nzdSum + 0.0) / ndSum;
                if (pzd[z][d] > 1)
                    printf("pzd error!!!\n");
                //pzd[z][d] = (nzd[z][d] + alpha) / (K * alpha + nd[d]);
            }
            for (int w = 0; w < W; w ++)
                pwz[w][z] = (nzw[z][w] + beta) / (W * beta + nw[z]);
        }

        int process = (iter + 1) * 100 / maxIter;
        if (process > lastProcess)
        {
            /*
            for (unsigned int i = 0; i < corpus -> labels.size(); i ++)
            {
                int w = corpus -> labels[i] -> word;
                if (strcmp(corpus -> wordList[w].c_str(), "formation") != 0)
                    continue;
                printf("%s", corpus -> wordList[w].c_str());
                for (int z = 0; z < K; z ++)
                    printf(" %.5lf", pwz[w][z]);
                printf("\n");
                break;
            }
            */
            printf("Estimating Parameters of CST: %d%%......\n", process);
            lastProcess = process;
        }
    }

    for (int z = 0; z < K; z ++)
    {
        if (nzd && nzd[z])
            delete nzd[z];
        if (nzw && nzw[z])
            delete nzw[z];
    }
    for (int d = 0; d < D; d ++)
    {
        if (Z && Z[d])
            delete[] Z[d];
        if (C && C[d])
            delete[] C[d];
    }
    if (links)
        delete[] links;
    if (nzd)
        delete[] nzd;
    if (nzw)
        delete[] nzw;
    if (nc)
        delete[] nc;
    if (ns)
        delete[] ns;
    if (C)
        delete[] C;
    if (Z)
        delete[] Z;
    printf("CST: Estimation Over!\n########################################\n");

}

DWT::~DWT()
{
    //printf("Deleting DWT!\n");
    /*
    if (nzd)
    {
        for (int z = 0; z < topicNum; z ++)
            if (nzd[z])
                delete nzd[z];
        delete[] nzd;
    }
    if (nzw)
    {
        for (int z = 0; z < topicNum; z ++)
            if (nzw[z])
                delete nzw[z];
        delete[] nzw;
    }
    if (nd)
        delete nd;
    if (nw)
        delete nw;
    */

    if (pzd)
    {
        for (int z = 0; z < topicNum; z ++)
            if (pzd[z])
                delete pzd[z];
        delete[] pzd;
    }

    if (pwz)
    {
        for (int w = 0; w < corpus -> wordNum; w ++)
            if (pwz[w])
                delete pwz[w];
        delete[] pwz;
    }

    if (corpus)
        delete corpus;
}
