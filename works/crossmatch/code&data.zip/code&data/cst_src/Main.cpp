#include "DataSet.h"
#include "LDA.h"
#include "Linker.h"
#include "PreProcessor.h"

string      getTopicFile(int model, int topicNum, int maxEstimateIterNum, double beta, double gamma)
{
    string topicFile = "data/";
    
    if (model == 1)
        topicFile += "dwt_k";
    else
        topicFile += "lda_k";

    topicFile += Util::Num2Str(topicNum) + 
                       "_i" + Util::Num2Str(maxEstimateIterNum) + "_g" +
                       Util::Num2Str(gamma) + "_b" + Util::Num2Str(beta) + ".out";
    return topicFile;
}

void    ShowUsage()
{
    printf("Cross-Source Topic model v0.1                                   \n");
    printf("     by Yang Yang, Tsinghua University                          \n");
    printf("                                                                \n");
    printf("Usage: CST -train -test -s1 -s2 -stopw [options]                \n");
    printf("options include -topic -iter -model -alpha -beta -g1 -g2        \n");
    printf("\n");
    //printf("##############################################################  \n");
    printf("   -train   string      : the train file                        \n");
    printf("   -test    string      : the test file                         \n");
    printf("   -s1      string      : documents in source1                  \n");
    printf("   -s2      string      : documents in source2                  \n");
    printf("CST model will match documents from source1 to source2.         \n");
    printf("   -stopw   string      : stop word file                        \n");
    printf("   -topic   int         : number of topics, 50 as default       \n");
    printf("   -iter    int         : number of iterations, 100 as default  \n");
    printf("   -model   int         : choose the model CST (1) or LDA (0)   \n");
    printf("   -g1      int         : gamma 1 used in CST, 4 as default     \n");
    printf("   -g2      int         : gamma 2, 1 as default                 \n");
    //printf("##############################################################  \n");
    printf("\n");
    exit( 0 );
}


int main(int argc, char* argv[])
{
    // parameters setting
    bool PREPROCESS = true;                 // preprocess or not
    int TOPIC_NUM = 50;                     // numebr of topics
    int MAX_ESTIMATE_ITER = 100;            // number of estimation iterations
    int MODEL = 1;                          // 0: lda; 1: dwt
    double ALPHA = 50 / TOPIC_NUM; 
    double BETA = 0.01;
    double GAMMA[2] = {4, 1};               // gamma[0]: choose self; gamma[1]: others

    // data files
    string TRAIN_DATA_FILE = "";
    string TEST_DATA_FILE = "";
    string PATENT_FILE = "";
    string WIKI_FILE = "";
    string TOPIC_WORDS_FILE = "";

    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-train") == 0)
        {
            TRAIN_DATA_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-test") == 0)
        {
            TEST_DATA_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-s2") == 0)
        {
            PATENT_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-s1") == 0)
        {
            WIKI_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-stopw") == 0)
        {
            TOPIC_WORDS_FILE = argv[++i];
        }
        if (strcmp(argv[i], "-topic") == 0)
        {
            TOPIC_NUM = Util::String2Int(argv[++i]);
        }
        if (strcmp(argv[i], "-iter") == 0)
        {
            MAX_ESTIMATE_ITER = Util::String2Int(argv[++i]);
        }
        if (strcmp(argv[i], "-model") == 0)
        {
            MODEL = Util::String2Int(argv[++i]);
        }
        if (strcmp(argv[i], "-g1") == 0)
        {
            GAMMA[0] = Util::String2Int(argv[++i]);
        }
        if (strcmp(argv[i], "-g2") == 0)
        {
            GAMMA[1] = Util::String2Int(argv[++i]);
        }

        i ++;
    }

    if (TRAIN_DATA_FILE == "" || TEST_DATA_FILE == "" || PATENT_FILE == "" ||
        WIKI_FILE == "" || TOPIC_WORDS_FILE == "")
    {
        ShowUsage();
        return 0;
    }

    if (MODEL == 0)
        printf("Matching cross-source documents by LDA.\n");
    else
        printf("Matching cross-source documents by CST.\n");

    if (PREPROCESS)
    {
        vector<Document*> docList;
        PreProcessor::ReadStopWords(TOPIC_WORDS_FILE.c_str());
        vector<Document*> wikiList = PreProcessor::ReadWikiFromFile(WIKI_FILE.c_str());
        for (unsigned int i = 0; i < wikiList.size(); i ++)
            docList.push_back(wikiList[i]);
        vector<Document*> patentList = PreProcessor::ReadPatentFromFile(PATENT_FILE.c_str());
        for (unsigned int i = 0; i < patentList.size(); i ++)
            docList.push_back(patentList[i]);
        // 0: train; 1: test
        PreProcessor::ReadAnswerFromFile(TRAIN_DATA_FILE.c_str(), docList, 0);
        PreProcessor::ReadAnswerFromFile(TEST_DATA_FILE.c_str(), docList, 1);
        PreProcessor::WriteToFile("data.in", docList);
    }    

    string topicFile = getTopicFile(MODEL, TOPIC_NUM, MAX_ESTIMATE_ITER, GAMMA[0], BETA);
    Linker* linker = new Linker();
    linker -> SetAlpha(ALPHA);
    linker -> SetBeta(BETA);
    linker -> SetGamma(GAMMA);
    linker -> BuildDataSet("data.in", "words.in");
    linker -> ModelCorpus(TOPIC_NUM, MAX_ESTIMATE_ITER, MODEL, topicFile.c_str());
    //linker -> ModelSimilarity("data/similarity_apple.in");
    //linker -> SaveStandardLinks("data/ans");
    linker -> Link(MODEL);
    //linker -> Evaluate(links);
}
