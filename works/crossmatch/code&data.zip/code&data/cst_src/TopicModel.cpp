#include <cstdio>
#include <cmath>
#include "TopicModel.h"

using namespace std;

bool        cmp(pair<int, double> a, pair<int, double> b)
{
    return a.second > b.second;
}

int         TopicModel::SaveTopic(const char* fileDir, int top)
{
    printf("Saving topics to %s...\n", fileDir);
    int W = corpus -> wordNum;
    int K = topicNum;
    bool done[W];
    FILE* fout = fopen(fileDir, "w");
    int hit[K][top];
    memset(hit, 0, sizeof(hit));
    for (int k = 0; k < K; k ++)
    {
        fprintf(fout, "Topic #%d:\n", k);
        memset(done, false, sizeof(done));
        for (int t = 0; t < top; t ++)
        {
            double max = 0;
            int wid;
            for (int w = 0; w < W; w ++)
            {
                if (pwz[w][k] > max && (! done[w]))
                {
                    max = pwz[w][k];
                    wid = w;
                }
            }
            done[wid] = true;
            fprintf(fout, "%s     %.5lf\n", corpus -> wordList[wid].c_str(), max);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);

    return 0;
}

int         TopicModel::SaveTopicDis(const char* fileDir)
{
    printf("Save topic distribution to %s.\n", fileDir);
    int D = corpus -> docNum;
    int K = topicNum;
    FILE* fout = fopen(fileDir, "w");
    for (int d = 0; d < D; d ++)
    {
        fprintf(fout, "%s", corpus -> docs[d] -> title.c_str());
        for (int z = 0; z < K; z ++)
        {
            fprintf(fout, " %.6lf", pzd[z][d]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

int         TopicModel::SaveToFile(const char* fileDir)
{
    //printf("Saving model to %s...\n", fileDir);
    int D = corpus -> docNum;
    int W = corpus -> wordNum;
    int K = topicNum;
    FILE* fout = fopen(fileDir, "w");
    fprintf(fout, "%d %d %d\n", D, W, K);
    for (int z = 0; z < K; z ++)
    {
        for (int w = 0; w < W; w ++)
        {
            fprintf(fout, "%.6lf ", pwz[w][z]);
        }
        fprintf(fout, "\n");
    }
    for (int d = 0; d < D; d ++)
    {
        for (int z = 0; z < K; z ++)
        {
            fprintf(fout, "%.6lf ", pzd[z][d]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);
    return 0;
}

double      TopicModel::CosineSimilarity(int d1, int d2)
{
    //printf("%d\n", topicNum);
    //printf("%.5lf %.5lf\n", pzd[0][d1], pzd[0][d2]);
    double s = 0;
    double a = 0;
    double b = 0;
    for (int z = 0; z < topicNum; z ++)
    {
        s += pzd[z][d1] * pzd[z][d2];
        a += pzd[z][d1] * pzd[z][d1];
        b += pzd[z][d2] * pzd[z][d2];
    }
    //printf("%.5lf %.5lf\n", a, b);
    return s / (sqrt(a) * sqrt(b));
}

double      TopicModel::KLDivergence(int d1, int d2)
{
    double s = 0;
    for (int z = 0; z < topicNum; z ++)
        s += pzd[z][d1] * log(pzd[z][d1] / pzd[z][d2]);
    return s;
}

double      TopicModel::DocSimilarity(int d1, int d2)
{
    /*
    double a = KLDivergence(d1, d2);
    double b = KLDivergence(d2, d1);
    return (a + b) / 2;
    */
    return CosineSimilarity(d1, d2);
}

int         TopicModel::StatisticHotWords(int k, const char* fileDir)
{
    printf("Saving hot words to %s...\n", fileDir);
    FILE* fout = fopen(fileDir, "w");
    for (int d = 0; d < corpus -> docNum; d ++)
    {
        vector<pair<int, double> > words = HotWords(d);
        fprintf(fout, "##########     %s     ##########\n", corpus -> docs[d] -> title.c_str());
        for (int i = 0; i < k; i ++)
        {
            if (i >= (int) corpus -> docs[d] -> words.size())
                break;
            //printf("%d %d\n", d, words[i].first);
            string word = corpus -> wordList[words[i].first];
            fprintf(fout, "%s %.5lf\n", word.c_str(), words[i].second);
        }
    }
    fclose(fout);
    return 0;
}

vector<pair<int, double> >   TopicModel::HotWords(int d)
{
    vector<pair<int, double> > result;
    Document* doc = corpus -> docs[d];
    for (unsigned int i = 0; i < doc -> words.size(); i ++)
    {
        int w = doc -> words[i];
        double p = 0;
        for (int z = 0; z < topicNum; z ++)
        {
            p += pzd[z][d] * pwz[w][z];
        }
        result.push_back(make_pair(w, p));
    }
    sort(result.begin(), result.end(), cmp);
    return result;
}
