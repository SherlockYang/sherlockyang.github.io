#pragma once

#include <utility>
#include "DataSet.h"

using namespace std;

class TopicModel 
{
public:
    int                         topicNum;
    Corpus*                     corpus;
    double**                    pwz;
    double**                    pzd;

    int                         SaveToFile(const char* fileDir);
    int                         SaveTopicDis(const char* fileDir);
    double                      DocSimilarity(int d1, int d2);
    double                      CosineSimilarity(int d1, int d2);
    double                      KLDivergence(int d1, int d2);
    vector<pair<int, double> >  HotWords(int d);
    int                         StatisticHotWords(int k, const char* fileDir);
    int                         SaveTopic(const char* fileDir, int top);
};
