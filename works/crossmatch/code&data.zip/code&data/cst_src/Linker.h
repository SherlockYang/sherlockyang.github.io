#pragma once

#include <vector>
#include <set>
#include "DataSet.h"
#include "LDA.h"
#include "DWT.h"

using namespace std;

class Linker
{
public:
    DataSet*            dataSet;
    LDA*                lda;
    DWT*                dwt;
    set<int>            linkSet;
    double              alpha;
    double              beta;
    double*             gamma;
    
    int                 BuildDataSet(const char* dataFile, const char* wordFile);
    int                 ModelCorpus(int topicNum, int maxIter, int model, const char* topicFile);
    int                 Evaluate(vector<Label*> results);
    bool                HasLink(int doc1, int doc2);
    void                ModelSimilarity(const char* linkFile);
    void                SaveStandardLinks(const char* ansFile);
    void                SetAlpha(double alpha);
    void                SetBeta(double beta);
    void                SetGamma(double* gamma);
    void                Link(int model);
};
