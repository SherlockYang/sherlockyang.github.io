#include "Util.h"
#include "PreProcessor.h"

#include <string>
#include <vector>
#include <set>
#include <map>

#define MAX_BUF_SIZE 655360

using std::string;
using std::vector;
using std::map;
using std::set;

map<string, int>    dict;
map<string, int>    docMap;
vector<Document*>   docs;
vector<string>      wordList;
set<string>         stopwords;

int             getId(map<int, int> dict, const int key)
{
    map<int, int>::iterator it = dict.find(key);
    if (it != dict.end())
    {
        return it->second;
    }
    else
    {
        return dict.size();
    }
}

string          replaceAll(const char* str)
{
    string result;
    bool flag = true;

    for (unsigned int i = 0; i < strlen(str); i ++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
        {
            result += 'a' + (str[i] - 'A');
            flag = false;
        } 
        else 
        { 
            if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= '0' && str[i] <= '9'))
            {
                result += str[i];
                flag = false;
            } 
            else 
            {
                if (! flag)
                    result += " ";
                flag = true;
            }
        }
    }
    return result;
}


bool                    isStopword(string word)
{
    if (stopwords.count(word) > 0 || word.length() < 2)
        return true;
    bool flag = true;
    for (unsigned int i = 0; i < word.length(); i ++)
        if (word[i] >= 'a' && word[i] <= 'z')
        {
            flag = false;
            break;
        }
    return flag;
}

vector<Document*>       PreProcessor::ReadWikiFromFile(const char* dataFile)
{
    printf("reading source1 documents from %s\n", dataFile);
    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;

    FILE        *fin = fopen(dataFile, "r");

    map<int, int> doc_dict;
    vector<string> terms; 
    vector<Document*> result;

    while (true)
    {
        // Read title
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        Document* doc = new Document();
        doc -> source = 0;
        for (unsigned int i = 0; i < strlen(eof) - 1; i ++)
            doc -> title += eof[i];

        // Read description
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
        {
            printf("Reading source1 documents error!\n");
            break;
        }
        line = replaceAll(eof);
        terms = Util::StringTokenize(line);
        doc_dict.clear();
        for (unsigned int i = 0; i < terms.size(); i ++)
        {
            if (isStopword(terms[i]))
                continue;
            int wid;
            map<string, int>::iterator it = dict.find(terms[i]);
            if (it != dict.end())
                wid = it->second;
            else
                wid = dict.size();
            if (wid >= (int) dict.size())
            {
                dict.insert(make_pair(terms[i], wid));
                wordList.push_back(terms[i]);
            }
            int op = getId(doc_dict, wid);
            if (op >= (int) doc -> words.size())
            {
                doc_dict.insert(make_pair(wid, op));
                doc -> words.push_back(wid);
                doc -> counts.push_back(1);
            } 
            else 
                doc -> counts[op] += 1; 
        }
        int val = (int) docMap.size();
        docMap.insert(make_pair(doc -> title, val));
        result.push_back(doc);
        //printf("%d %d\n", (int) result.size(), (int) dict.size());

        // read the links
        eof = fgets(buf, MAX_BUF_SIZE, fin);
    }
    printf("#wiki terms: %d\n", (int) result.size());
    fclose(fin);

    return result;
}

vector<Document*>       PreProcessor::ReadPatentFromFile(const char* dataFile)
{
    printf("reading source2 documents from %s\n", dataFile);
    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;

    FILE        *fin = fopen(dataFile, "r");

    map<int, int> doc_dict;
    vector<string> tmp;
    vector<Document*> result;

    while (true)
    {
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        
        // Read ID
        Document *doc = new Document();
        doc -> links.clear();
        doc_dict.clear();
        for (unsigned int i = 0; i < strlen(eof) - 1; i ++)
            doc -> title += eof[i];

        // Read title & abstract & claim
        for (int k = 0; k < 3; k ++)
        {
            eof = fgets(buf, MAX_BUF_SIZE, fin);
            if (eof == NULL)
            {
                printf("Reading source2 documents error!\n");
                return result;
            }

            line = replaceAll(eof);
            vector<string> terms = Util::StringTokenize(line);
            for (unsigned int i = 0; i < terms.size(); i ++)
            {
                if (isStopword(terms[i]))
                    continue;
                int wid;
                map<string, int>::iterator it = dict.find(terms[i]);
                if (it != dict.end())
                    wid = it->second;
                else
                    wid = dict.size();
                if (wid >= (int) dict.size())
                {
                    dict.insert(make_pair(terms[i], wid));
                    wordList.push_back(terms[i]);
                }
                doc -> source = 1;
                int op = getId(doc_dict, wid);
                if (op >= (int) doc -> words.size())
                {
                    doc_dict.insert(make_pair(wid, op));
                    doc -> words.push_back(wid);
                    doc -> counts.push_back(1);
                }    
                else 
                    doc -> counts[op] += 1; 
            }
        }
        int val = (int) docMap.size();
        docMap.insert(make_pair(doc -> title, val));
        result.push_back(doc);

        // read inventors
        eof = fgets(buf, MAX_BUF_SIZE, fin);
    }
    printf("#patents: %d\n", (int) result.size());
    fclose(fin);

    return result;
}

int             PreProcessor::ReadAnswerFromFile(const char *fileDir, vector<Document*> docList, int test)
{
    printf("reading test & train answers from %s\n", fileDir);
    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;

    FILE        *fin = fopen(fileDir, "r");

    while (true)
    {
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        string tmp = "";
        for (unsigned int i = 0; i < strlen(eof) - 1; i ++)
            tmp += eof[i];
        int wikiId; 
        vector<string> termList = Util::StringSplit(tmp, ';');
        map<string, int>::iterator it = docMap.find(termList[0]);
        if (it != docMap.end())
            wikiId = it -> second;
        else
        {
            printf("%s could not been found!\n", termList[0].c_str());
            continue;
        }
        int patId;
        it = docMap.find(termList[1]);
        if (it != docMap.end())
            patId = it -> second;
        else
        {
            printf("%s could not been found!\n", termList[1].c_str());
            continue;
        }
        
        if (test == 0)
        {
            docList[wikiId] -> links.push_back(patId);
            docList[patId] -> links.push_back(wikiId);
        }
        else
        {
            docList[wikiId] -> tests.push_back(patId);
            docList[patId] -> tests.push_back(wikiId);
        }
    }

    return 0;
}

void            PreProcessor::WriteToFile(const char* file_dir, vector<Document*> docList)
{
    printf("Writing data to %s...\n", file_dir);
    FILE *fout = fopen(file_dir, "w");
    for (unsigned int i = 0; i < docList.size(); i ++)
    {
        //printf("%s\n", docList[i] -> title.c_str());
        fprintf(fout, "%s\n", docList[i] -> title.c_str());
        //printf("%d\n", (int) docList[i] -> links.size());
        fprintf(fout, "%d", docList[i] -> source);
        for (unsigned int j = 0; j < docList[i] -> links.size(); j ++)
        {
            //printf("%d ", docList[i] -> links[j]);
            fprintf(fout, " %d", docList[i] -> links[j]);
        }
        fprintf(fout, "\n");
        for (unsigned int j = 0; j < docList[i] -> tests.size(); j ++)
        {
            fprintf(fout, "%d ", docList[i] -> tests[j]);
        }
        fprintf(fout, "\n");
        for (unsigned int j = 0; j < docList[i] -> words.size(); j ++)
        {
            //printf("%d:%d ", docList[i] -> words[j], docList[i] -> counts[j]);
            fprintf(fout, "%d:%d ", docList[i] -> words[j], docList[i] -> counts[j]);
        }
        fprintf(fout, "\n");
    }
    fclose(fout);

    fout = fopen("words.in", "w");
    for (unsigned int i = 0; i < wordList.size(); i ++)
    {
        fprintf(fout, "%s\n", wordList[i].c_str());
    }
    fclose(fout);
}

void                    PreProcessor::ReadStopWords(const char* file)
{
    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;
    FILE* fin = fopen(file, "r");
    while (true)
    {
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        string word = Util::StringTokenize(eof)[0];
        if (isStopword(word))
            continue;
        //printf("%s\n", word.c_str());
        stopwords.insert(word);
    }
    fclose(fin);
}

