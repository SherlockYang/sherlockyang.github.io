#include "Util.h"
#include "DataSet.h"

#include <string>
#include <vector>
#include <map>

#define MAX_BUF_SIZE 65536

using std::string;
using std::vector;
using std::map;

// Corpus
Corpus::Corpus()
{
    wordNum = 0;
    linkNum = 0;
    docNum = 0;
}

void        Corpus::Clear()
{
    wordNum = 0;
    docNum = 0;
    docs.clear();
}

// DataSet
DataSet::DataSet()
{
    corpus = new Corpus();
}

int         DataSet::ReadWordList(const char* inputFile)
{
    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;

    FILE* fin = fopen(inputFile, "r");
    corpus -> wordList.clear();
    while (true)
    {
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        corpus -> wordList.push_back(Util::StringTokenize(eof)[0]);
    }
    return 0;
}

int         DataSet::ReadCorpus(const char* inputFile)
{
    printf("Reading corpus from %s ...\n", inputFile);

    char        buf[MAX_BUF_SIZE];
    char*       eof;
    string      line;

    FILE*       fin = fopen(inputFile, "r");

    vector<string> terms;
    vector<string> tmp;

    if (this -> corpus != NULL)
        this -> corpus -> Clear();
    else
        this -> corpus = new Corpus();

    int docId = 0;
    while (true)
    {
        Document* doc = new Document();
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        vector<string> titles = Util::StringTokenize(eof);
        doc -> title = titles[0];
        for (unsigned int i = 1; i < titles.size(); i ++)
            doc -> title += " " + titles[i];

        // read source and links
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        terms = Util::StringTokenize(eof);
        int source = Util::String2Int(terms[0]);
        doc -> source = source;
        for (unsigned int i = 1; i < terms.size(); i ++)
        {
            int link = Util::String2Int(terms[i]);
            if (link < 0)
                return -1;
            corpus -> linkNum += 1;
            doc -> links.push_back(link);
        }
        doc -> id = docId ++;

        // read tests
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            break;
        terms = Util::StringTokenize(eof);
        for (unsigned int i = 0; i < terms.size(); i ++)
        {
            int link = Util::String2Int(terms[i]);
            if (link < 0)
                return -1;
            doc -> tests.push_back(link);
        }

        // read words and frequency
        eof = fgets(buf, MAX_BUF_SIZE, fin);
        if (eof == NULL)
            return -1;
        terms = Util::StringTokenize(eof);
        for (unsigned int i = 0; i < terms.size(); i ++)
        {
            tmp = Util::StringSplit(terms[i], ':');
            if (tmp.size() != 2)
                return -1;
            int wid = Util::String2Int(tmp[0]);
            int count = Util::String2Int(tmp[1]);
            if (wid < 0 || count < 0)
                return -1;
            if (wid >= corpus -> wordNum)
                corpus -> wordNum = wid + 1;
            doc -> words.push_back(wid);
            doc -> counts.push_back(count);
        }
        
        corpus -> docs.push_back(doc);
    }

    corpus -> docNum = (int) corpus -> docs.size();
    printf("#documents: %d\n", (int) corpus -> docNum);
    printf("#words: %d\n", corpus -> wordNum);
    printf("#links: %d\n", (corpus -> linkNum) / 2);
    fclose(fin);

    return 0;
}
