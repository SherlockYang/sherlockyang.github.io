#pragma once

#include "DataSet.h"
#include "TopicModel.h"

#define myrand() (double) (((unsigned long) randomMT()) / 4294967296.)
#define NUM_INIT 1

class LDA : public TopicModel 
{
public:
    double      alpha;  // hyparameters of pzd
    double      beta;   // hyparameters of pwz
    int*        nd;
    int*        nw;
    int**       nzd;
    int**       nzw;
        
    int         InitEstimation(vector<int> **Z);
    int         Sampling(int w, int d);
    void        Estimation(int maxIter);
    void        GibbsSampling(int maxIter);
    double      Likelihood();
    
    LDA(int topicNum, Corpus* corpus, double alpha, double beta);
    ~LDA();
};
