<Required parameters>
Usage: CST -train -test -s1 -s2 -stopw [options]                
options include -topic -iter -model -alpha -beta -g1 -g2        

   -train   string      : the train file                        
   -test    string      : the test file                         
   -s1      string      : documents in source1                  
   -s2      string      : documents in source2                  
   -stopw   string      : stop word file                        
   -topic   int         : number of topics, 50 as default       
   -iter    int         : number of iterations, 100 as default  
   -model   int         : choose the model CST (1) or LDA (0)   
   -g1      int         : gamma 1 used in CST, 4 as default     
   -g2      int         : gamma 2, 1 as default

CST model will match documents from source1 to source2. 

<Input data>

-Documents from source1/source2:

[Title1]
[content1]
...

-Test/train file:

[title11][title12]
[title21][title22]
...

where in i-th instance, title[i1] is the title of document from source1,
title[i2] is the title of document from source2.

-stopword file
